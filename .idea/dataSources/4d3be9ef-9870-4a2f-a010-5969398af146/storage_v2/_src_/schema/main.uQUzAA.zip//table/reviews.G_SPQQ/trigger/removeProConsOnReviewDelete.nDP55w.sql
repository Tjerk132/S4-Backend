CREATE TRIGGER removeProConsOnReviewDelete AFTER DELETE on reviews
    FOR EACH ROW
BEGIN
    DELETE FROM "pros-and-cons"
    WHERE "pros-and-cons".reviewId = old.id;
END;

