CREATE TRIGGER addRoleForNewUser AFTER INSERT on users
BEGIN
    INSERT INTO "priority"
    (userId, role) values (new.id, 'USER');
END;

