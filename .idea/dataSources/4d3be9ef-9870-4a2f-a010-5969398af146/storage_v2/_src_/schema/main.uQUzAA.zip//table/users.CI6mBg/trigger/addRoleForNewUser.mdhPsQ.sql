CREATE TRIGGER addRoleForNewUser AFTER INSERT on users
BEGIN
    INSERT INTO roles
    (userId, role) values (new.id, 'USER');
END;

